This README.txt is distributed with an installer for the LabJackM (LJM) library.
Examples for LJM are available here:

https://labjack.com/support/software/examples/ljm

Once LJM is successfully installed, you have a C interface to LJM available.
LabJack also makes other language interfaces, such as:

 - Python
 - LabVIEW
 - MATLAB
 - Others

For the full list of language interfaces and to download examples, see the above
link.

If you decide LJM is not for you, direct Modbus TCP examples are available here:

https://labjack.com/support/software/examples/modbus

