#! /usr/bin/env sh

# Check out the SConstruct file for more info
../scons-local-2.5.1/scons.py "$@"

